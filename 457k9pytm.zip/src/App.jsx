
import React, { useState } from "react";

const internships = [
  {
    id: 1,
    title: "Web Development",
    company: "ABC Technologies",
    duration: "2 Months",
    description: "Learn HTML, CSS and JavaScript."
  },
  {
    id: 2,
    title: "Python Programming",
    company: "Code Solutions",
    duration: "3 Months",
    description: "Learn Python programming and problem solving."
  },
  {
    id: 3,
    title: "Data Analytics",
    company: "Data World",
    duration: "2 Months",
    description: "Learn data analysis and work with datasets."
  }
];

export default function App() {
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState("home");
  const [message, setMessage] = useState("");
  const [applications, setApplications] = useState(() => {
    try {
      return JSON.parse(
        localStorage.getItem("studentApplications") || "[]"
      );
    } catch {
      return [];
    }
  });

  function apply(event) {
    event.preventDefault();

    const form = event.target;
    const application = {
      name: form.name.value.trim(),
      email: form.email.value.trim(),
      roll: form.roll.value.trim(),
      internship: selected.title
    };

    const updated = [...applications, application];

    try {
      localStorage.setItem(
        "studentApplications",
        JSON.stringify(updated)
      );
      setApplications(updated);
      setMessage("Application submitted successfully!");
      form.reset();
    } catch {
      setMessage("Unable to save. Please check your browser settings.");
    }
  }

  return (
    <div>
      <header>
        <h1>Student Internship Portal</h1>
        <p>Discover internships and build your future!</p>
      </header>

      <nav>
        <button onClick={() => { setPage("home"); setMessage(""); }}>
          Home
        </button>
        <button onClick={() => { setPage("applications"); setMessage(""); }}>
          My Applications
        </button>
      </nav>

      <main>
        {page === "home" && (
          <>
            <h2>Available Internships</h2>

            <div className="cards">
              {internships.map((job) => (
                <div className="card" key={job.id}>
                  <h3>{job.title}</h3>
                  <p>Company: {job.company}</p>
                  <p>Duration: {job.duration}</p>

                  <button onClick={() => {
                    setSelected(job);
                    setPage("details");
                    setMessage("");
                  }}>
                    View Details
                  </button>
                </div>
              ))}
            </div>
          </>
        )}

        {page === "details" && selected && (
          <div className="panel">
            <h2>{selected.title}</h2>
            <p>Company: {selected.company}</p>
            <p>Duration: {selected.duration}</p>
            <p>{selected.description}</p>

            <button onClick={() => {
              setPage("apply");
              setMessage("");
            }}>
              Apply Now
            </button>

            <button onClick={() => setPage("home")}>
              Back
            </button>
          </div>
        )}

        {page === "apply" && selected && (
          <div className="panel">
            <h2>Internship Application</h2>

            <form onSubmit={apply}>
              <label>Full Name</label>
              <input name="name" required placeholder="Enter your name" />

              <label>Email Address</label>
              <input
                name="email"
                type="email"
                required
                placeholder="Enter your email"
              />

              <label>Roll Number</label>
              <input name="roll" required placeholder="Enter roll number" />

              <p>Internship: <strong>{selected.title}</strong></p>

              <button type="submit">Submit Application</button>
            </form>

            <p className="success">{message}</p>

            <button onClick={() => setPage("home")}>Back to Home</button>
          </div>
        )}

        {page === "applications" && (
          <>
            <h2>My Applications</h2>

            {applications.length === 0 ? (
              <p>No applications submitted yet.</p>
            ) : (
              applications.map((app, index) => (
                <div className="card" key={index}>
                  <h3>{app.internship}</h3>
                  <p>Name: {app.name}</p>
                  <p>Email: {app.email}</p>
                  <p>Roll Number: {app.roll}</p>
                </div>
              ))
            )}
          </>
        )}
      </main>

      <footer>
        <p>© 2026 Student Internship Portal</p>
      </footer>
    </div>
  );
}
